public interface IInteractable
{
    // Appel� quand le joueur interagit (E). Retourne true si l�interaction a r�ussi.
    bool Interact(FpsController interactor);
}
